import json
import boto3
import os
import uuid
import base64
import pathlib
import datatier
import urllib.parse
import string
import time
import requests

from configparser import ConfigParser
from pypdf import PdfReader

# Initialize AWS Clients
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: transcribe**")
    
    # 
    # in case we get an exception, initial this filename
    # so we can write an error message if need be:
    #
    bucketkey_results_file = ""
    
    #
    # setup AWS based on config file:
    #
    config_file = 'benfordapp-config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)
    
    #
    # configure for S3 access:
    #
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    
    bucketname = configur.get('s3', 'bucket_name')
    
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    #
    # configure for RDS access
    #
    rds_endpoint = configur.get('rds', 'endpoint')
    rds_portnum = int(configur.get('rds', 'port_number'))
    rds_username = configur.get('rds', 'user_name')
    rds_pwd = configur.get('rds', 'user_pwd')
    rds_dbname = configur.get('rds', 'db_name')
    
    #
    # this function is event-driven by a PDF being
    # dropped into S3. The bucket key is sent to 
    # us and obtain as follows:
    #
    bucketkey = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    print("bucketkey:", bucketkey)
      
    extension = pathlib.Path(bucketkey).suffix
    
    if extension != ".mp3" : 
      raise Exception("expecting S3 document to have .mp3 extension")
    
    bucketkey_results_file = bucketkey[0:-4] + ".txt"
    
    print("bucketkey results file:", bucketkey_results_file)
      
    #
    # download PDF from S3 to LOCAL file system:
    #
    print("**DOWNLOADING '", bucketkey, "'**")

    #
    # TODO #1 of 8: where do we write local files? Replace
    # the ??? with the local directory where we have access.
    # 
    local_pdf = "/tmp/data.mp3"
    
    bucket.download_file(bucketkey, local_pdf)

    print("**PROCESSING local mp3**")
    

    #
    # TODO #2 of 8: update status column in DB for this job,
    # change the value to "processing - starting". Use the
    # bucketkey --- stored as datafilekey in the table ---
    # to identify the row to update. Use the datatier.
    #
    # open connection to the database:
    #
    print("**Opening DB connection**")
    #
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)
    #
    sql = '''update jobs set status = 'processing - starting' where datafilekey = %s'''
    datatier.perform_action(dbConn, sql, parameters=[bucketkey])

    transcription_job_name = bucketkey[-40:]
    print("transcription_job_name:", transcription_job_name)
    client = boto3.client('transcribe', region_name='us-east-2')

    request = client.start_transcription_job(
      TranscriptionJobName=transcription_job_name,
      Media={'MediaFileUri': 's3://benfordapp-brandon-do/' + bucketkey},
      MediaFormat='mp3',
      LanguageCode='en-US'
    )

    # poll for results
    while True:
      request = client.get_transcription_job(TranscriptionJobName=transcription_job_name)
      if request['TranscriptionJob']['TranscriptionJobStatus'] == 'COMPLETED':
        break
      time.sleep(1)

    transcript_uri = request['TranscriptionJob']['Transcript']['TranscriptFileUri']
    response = requests.get(transcript_uri)
    transcript_data = response.json()['results']['transcripts'][0]['transcript']
    print(transcript_data)

    #
    local_results_file = "/tmp/results.txt"

    print("local results file:", local_results_file)

    with open(local_results_file, "w") as outfile:
      outfile.write(transcript_data)

    #
    # upload the results file to S3:
    #
    print("**UPLOADING to S3 file", bucketkey_results_file, "**")

    bucket.upload_file(local_results_file,
                       bucketkey_results_file,
                       ExtraArgs={
                         'ACL': 'public-read',
                         'ContentType': 'text/plain'
                       })
    

    sql = '''update jobs set status = 'completed', resultsfilekey = %s where datafilekey = %s'''
    datatier.perform_action(dbConn, sql, parameters=[bucketkey_results_file, bucketkey])
    print("changed status, completed")

    #
    # Invoke `final_proj_analyze` to analyze transcription
    #
    invoke_analysis_lambda(bucketkey_results_file, transcript_data, bucketkey)

    #
    # done!
    #
    # respond in an HTTP-like way, i.e. with a status
    # code and body in JSON format:
    #
    print("**DONE, returning success**")
    
    return "success"
   
    
  #
  # on an error, try to upload error message to S3:
  #
  except Exception as err:
    print("**ERROR**")
    print(str(err))
    
    local_results_file = "/tmp/results.txt"
    outfile = open(local_results_file, "w")

    outfile.write(str(err))
    outfile.write("\n")
    outfile.close()
    
    if bucketkey_results_file == "": 
      #
      # we can't upload the error file:
      #
      pass
    else:
      # 
      # upload the error file to S3
      #
      print("**UPLOADING**")
      #
      bucket.upload_file(local_results_file,
                         bucketkey_results_file,
                         ExtraArgs={
                           'ACL': 'public-read',
                           'ContentType': 'text/plain'
                         })

    #
    # update jobs row in database:
    #
    # TODO #8 of 8: open connection, update job in database
    # to reflect that an error has occurred. The job is 
    # identified by the bucketkey --- datafilekey in the 
    # table. Set the status column to 'error' and set the
    # resultsfilekey column to the contents of the variable
    # bucketkey_results_file.
    #
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)
    sql = '''update jobs set status = 'error', resultsfilekey = %s where datafilekey = %s'''
    datatier.perform_action(dbConn, sql, parameters=[bucketkey_results_file, bucketkey])
    print("changed status, error")

    #
    # done, return:
    #    
    return {
      'statusCode': 500,
      'body': json.dumps(str(err))
    }

def invoke_analysis_lambda(file_key, transcribed_text, audio_key):
    try:
        print(f"Invoking final_proj_analyze with file_key: {file_key}") 
        response = lambda_client.invoke(
            FunctionName="final_proj_analyze",
            InvocationType="Event",  # Runs asynchronously
            Payload=json.dumps({"file_key": file_key, "text": transcribed_text, "audio_key": audio_key})
        )
        print("Invoked final_proj_analyze Lambda:", response)
    except Exception as e:
        print("Error invoking final_proj_analyze:", str(e))
