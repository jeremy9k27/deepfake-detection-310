import boto3
import json
import uuid
import os
import urllib.parse
import pathlib
from datetime import datetime
from configparser import ConfigParser

# Initialize AWS Clients
lambda_client = boto3.client('lambda')

# Set up AWS profile (same as `final_proj_transcribe`)
config_file = 'benfordapp-config.ini'
os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file

configur = ConfigParser()
configur.read(config_file)

s3_profile = 's3readwrite'
boto3.setup_default_session(profile_name=s3_profile)

# Initialize S3 client
s3 = boto3.client('s3')
comprehend = boto3.client('comprehend')

# Load S3 bucket name from config file
BUCKET_NAME = configur.get('s3', 'bucket_name')

def lambda_handler(event, context):
    try:
        print(f"Received event in final_proj_analyze: {json.dumps(event, indent=2)}")

        # Extract inputs
        file_key = event.get("file_key", "")
        transcribed_text = event.get("text", "")
        audio_key = event.get("audio_key", "")

        if not transcribed_text:
            raise ValueError("No text provided for analysis")

        print(f"Processing file: {file_key}")
        
        # Get the bucketkey for results file using the same logic
        bucketkey = file_key
            
        print("bucketkey:", bucketkey)
        
        extension = pathlib.Path(bucketkey).suffix
        
        # Create results file path by replacing extension with .txt
        bucketkey_results_file = bucketkey[0:-4] + ".txt"
        
        print("bucketkey results file:", bucketkey_results_file)

        sentiment_response = comprehend.detect_sentiment(
            Text=transcribed_text, LanguageCode="en"
        )
        sentiment = sentiment_response["Sentiment"]
        sentiment_scores = sentiment_response["SentimentScore"]

        tone_response = comprehend.detect_syntax(
            Text=transcribed_text, LanguageCode="en"
        )
        tone_score = analyze_tone_irregularities(tone_response)

        ai_likelihood = classify_ai_speech(tone_score)

        print(f"Sentiment Analysis: {sentiment}")
        print(f"AI Speech Likelihood: {ai_likelihood}")

        analysis_results = f"\n\n--- Sentiment & AI Analysis ---\n"
        analysis_results += f"Sentiment: {sentiment}\n"
        analysis_results += f"Sentiment Scores: {json.dumps(sentiment_scores, indent=2)}\n"
        analysis_results += f"Tone Score: {tone_score}\n"
        analysis_results += f"AI Speech Likelihood: {ai_likelihood}\n"

        complete_content = transcribed_text + analysis_results
        
        local_results_file = "/tmp/results.txt"
        print("local results file:", local_results_file)
        
        with open(local_results_file, "w") as outfile:
            outfile.write(complete_content)
            
        print(f"**UPLOADING to S3 file {bucketkey_results_file} **")
        
        # Get S3 resource to use upload_file method
        s3_resource = boto3.resource('s3')
        bucket = s3_resource.Bucket(BUCKET_NAME)
        
        bucket.upload_file(
            local_results_file,
            bucketkey_results_file,
            ExtraArgs={
                'ACL': 'public-read',
                'ContentType': 'text/plain'
            }
        )
        
        print(f"Successfully uploaded analysis file to S3: {bucketkey_results_file}")

        #
        # Invoke `final_proj_extract`
        #
        invoke_extract_lambda(bucketkey_results_file, complete_content, audio_key)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "file_key": file_key,
                "results_file": bucketkey_results_file,
                "sentiment": sentiment,
                "sentiment_scores": sentiment_scores,
                "tone_score": tone_score,
                "ai_speech_likelihood": ai_likelihood,
                "s3_file": f"s3://{BUCKET_NAME}/{bucketkey_results_file}"
            })
        }

    except Exception as e:
        print(f"Error in final_proj_analyze: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}

def analyze_tone_irregularities(tone_data):
    token_count = len(tone_data["SyntaxTokens"])
    noun_count = sum(1 for t in tone_data["SyntaxTokens"] if t["PartOfSpeech"]["Tag"] == "NOUN")
    verb_count = sum(1 for t in tone_data["SyntaxTokens"] if t["PartOfSpeech"]["Tag"] == "VERB")

    # Normalize tone score, avoiding division by zero
    tone_score = noun_count / (verb_count + 1)
    return round(tone_score, 2)

def classify_ai_speech(tone_score):
    if tone_score < 0.7:
        return "High"  # Likely AI-generated
    elif tone_score < 1.2:
        return "Medium"  # Possibly AI
    else:
        return "Low"  # Likely Human

def invoke_extract_lambda(file_key, text, audio_key):
    try:
        print(f"Invoking final_proj_analyze with file_key: {file_key}") 
        response = lambda_client.invoke(
            FunctionName="final_proj_extract",
            InvocationType="Event",  # Runs asynchronously
            Payload=json.dumps({"file_key": file_key, "text": text, "audio_key": audio_key})
        )
        print("Invoked final_proj_extract Lambda:", response)
    except Exception as e:
        print("Error invoking final_proj_extract:", str(e))