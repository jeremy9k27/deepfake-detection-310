import boto3
import json
import uuid
import os
import urllib.parse
import pathlib
import mutagen
from datetime import datetime
from configparser import ConfigParser

# Set up AWS profile
config_file = 'benfordapp-config.ini'
os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file

configur = ConfigParser()
configur.read(config_file)

s3_profile = 's3readwrite'
boto3.setup_default_session(profile_name=s3_profile)

# Initialize S3 client
s3 = boto3.client('s3')

# Load S3 bucket name from config file
BUCKET_NAME = configur.get('s3', 'bucket_name')

def lambda_handler(event, context):
    try:
        print(f"Received event in final_proj_extract: {json.dumps(event, indent=2)}")

        # Extract inputs
        file_key = event.get("file_key", "")
        text = event.get("text", "")
        audio_key = event.get("audio_key", "")

        print(f"Processing file: {file_key}")
        
        # Get the bucketkey for results file using the same logic
        bucketkey = file_key
            
        print("bucketkey:", bucketkey)
        
        extension = pathlib.Path(bucketkey).suffix
        
        # Create results file path by replacing extension with .txt
        bucketkey_results_file = bucketkey[0:-4] + ".txt"
        
        print("bucketkey results file:", bucketkey_results_file)

        # Get file
        print(f"**DOWNLOADING from S3 file {bucketkey} **")
        s3.download_file(BUCKET_NAME, audio_key, "/tmp/data.mp3")

        # Extract metadata
        print("**Extracting metadata**")
        metadata = {}
        audio_file = mutagen.File("/tmp/data.mp3")
        if audio_file is not None:
            # Technical properties
            metadata['sample_rate'] = getattr(audio_file.info, 'sample_rate', None)
            print("sample_rate:", metadata['sample_rate'])
            metadata['bitrate'] = getattr(audio_file.info, 'bitrate', None)
            print("bitrate:", metadata['bitrate'])
            metadata['channels'] = getattr(audio_file.info, 'channels', None)
            print("channels:", metadata['channels'])
            metadata['length'] = getattr(audio_file.info, 'length', None)
            print("length:", metadata['length'])
            metadata['codec'] = getattr(audio_file.info, 'codec_description', getattr(audio_file.info, 'codec', None))
            print("codec:", metadata['codec'])

            # File tags (artist, title, etc.)
            if hasattr(audio_file, 'tags') and audio_file.tags:
                metadata['tags'] = {k: str(v) for k, v in audio_file.tags.items()}
            else:
                metadata['tags'] = {}
            print("tags:", metadata['tags'])

        # Analyze metadata
        suspicious_indicators = []
    
        # 1. Common AI generation sample rates
        if metadata.get('sample_rate') in [16000, 22050, 24000]:
            suspicious_indicators.append('Common AI sample rate detected')
        
        # 2. Perfect duration (whole seconds)
        if metadata.get('length') and abs(round(metadata.get('length')) - metadata.get('length')) < 0.05:
            suspicious_indicators.append('Suspiciously precise duration')
        
        # 3. Missing metadata tags
        if not metadata.get('tags') or len(metadata.get('tags', {})) < 2:
            suspicious_indicators.append('Missing or minimal file tags')
        
        # 4. Missing codec information
        if not metadata.get('codec'):
            suspicious_indicators.append('Missing codec information')


        analysis_results = f"\n\n--- Metadata analysis ---\n"
        analysis_results += f"Sample rate: {metadata['sample_rate']}\n"
        analysis_results += f"Bitrate: {metadata['bitrate']}\n"
        analysis_results += f"Channels: {metadata['channels']}\n"
        analysis_results += f"Length: {metadata['length']}\n"
        analysis_results += f"Codec: {metadata['codec']}\n"
        analysis_results += f"Tags: {json.dumps(metadata['tags'], indent=2)}\n"
        analysis_results += f"Suspicious indicators: {suspicious_indicators}\n"

        complete_content = text + analysis_results
        
        local_results_file = "/tmp/results.txt"
        print("local results file:", local_results_file)
        
        with open(local_results_file, "w") as outfile:
            outfile.write(complete_content)
            
        print(f"**UPLOADING to S3 file {bucketkey_results_file} **")
        
        # Get S3 resource to use upload_file method
        s3_resource = boto3.resource('s3')
        bucket = s3_resource.Bucket(BUCKET_NAME)
        
        bucket.upload_file(
            local_results_file,
            bucketkey_results_file,
            ExtraArgs={
                'ACL': 'public-read',
                'ContentType': 'text/plain'
            }
        )
        
        print(f"Successfully uploaded analysis file to S3: {bucketkey_results_file}")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Analysis completed and results file updated successfully",
                "bucketkey": bucketkey_results_file
            })
        }
    except Exception as e:
        print(f"Error in final_proj_extract: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}